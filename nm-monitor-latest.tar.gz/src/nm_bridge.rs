// Re-export systemd_net functions for backward compatibility
pub use crate::systemd_net::*;
