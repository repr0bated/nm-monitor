// Plugin implementations
pub mod net;
pub mod netcfg;

pub use net::NetStatePlugin;
pub use netcfg::NetcfgStatePlugin;
