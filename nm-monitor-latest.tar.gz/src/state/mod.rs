// State management module - pluggable declarative state system
pub mod manager;
pub mod plugin;
pub mod plugins;
